#pragma once

#include "myDesk.h"

class myDeskMatrix
{
private:
	myDesk desk;

public:
	myDeskMatrix(void);
	~myDeskMatrix(void);

	void draw();
};
