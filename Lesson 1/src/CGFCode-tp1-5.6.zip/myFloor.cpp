#include "myFloor.h"

myFloor::myFloor(void)
{
}

myFloor::~myFloor(void)
{
}

void myFloor::draw()
{
	glPushMatrix();
	glScaled(8, 0.1, 6);
	cube.draw();
	glPopMatrix();
}
