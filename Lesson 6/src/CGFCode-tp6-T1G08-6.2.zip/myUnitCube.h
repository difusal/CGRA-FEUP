#pragma once

#include "CGFobject.h"

class myUnitCube: public CGFobject
{
public:
	myUnitCube(void);
	~myUnitCube(void);

	void draw(bool applyTexturePoints);
};
