/*
 * MyRobot.cpp
 *
 *  Created on: May 2, 2014
 *      Author: henrique
 */

#include "MyRobot.h"

MyRobot::MyRobot() {
	// TODO Auto-generated constructor stub
}

void MyRobot::draw() {
	glPushMatrix();

	glTranslated(7.5, 0, 7.5);
	glRotated(-150, 0, 1, 0);

	glBegin (GL_POLYGON);
	glVertex3d(0.5, 0.3, 0);
	glVertex3d(-0.5, 0.3, 0);
	glVertex3d(0, 0.3, 2);
	glEnd();

	glPopMatrix();
}

MyRobot::~MyRobot() {
	// TODO Auto-generated destructor stub
}

