#include "TPinterface.h"

#include <cmath>
#include "LightingScene.h"
#include "Utilities.h"

TPinterface::TPinterface() {
}

void TPinterface::processKeyboard(unsigned char key, int x, int y) {
	// Uncomment below if you would like to process the default keys (e.g. 's' for snapshot, 'Esc' for exiting, ...)
	CGFinterface::processKeyboard(key, x, y);

	MyRobot* robot = ((LightingScene*) scene)->robot;
	double moveSpeed = 0.05, rotationSpeed = 2;

	switch (key) {
	case 'i':
		// move forward
		robot->x += moveSpeed * sin(degToRad(robot->rotation + 90));
		robot->z += moveSpeed * cos(degToRad(robot->rotation + 90));
		break;
	case 'j':
		// rotate left
		robot->rotation += rotationSpeed;
		break;
	case 'k':
		// move backwards
		robot->x -= moveSpeed * sin(degToRad(robot->rotation + 90));
		robot->z -= moveSpeed * cos(degToRad(robot->rotation + 90));
		break;
	case 'l':
		// rotate right
		robot->rotation -= rotationSpeed;
		break;
	case 'a':
		((LightingScene*) scene)->toggleShowTables();
		break;
	}
}

void TPinterface::initGUI() {
	char* text = new char[10];

	strcpy(text, "Lights");
	GLUI_Panel* varPanel = addPanel(text, 1);

	strcpy(text, "Light 0");
	addCheckboxToPanel(varPanel, text, &(((LightingScene*) scene)->light0IsOn),
			0);

	strcpy(text, "Light 1");
	addCheckboxToPanel(varPanel, text, &(((LightingScene*) scene)->light1IsOn),
			1);

	strcpy(text, "Light 2");
	addCheckboxToPanel(varPanel, text, &(((LightingScene*) scene)->light2IsOn),
			2);

	strcpy(text, "Light 3");
	addCheckboxToPanel(varPanel, text, &(((LightingScene*) scene)->light3IsOn),
			3);
}

void TPinterface::processGUI(GLUI_Control* ctrl) {
	switch (ctrl->user_id) {
	case 0:
		((LightingScene*) scene)->light0->disable();
		if (((LightingScene*) scene)->light0IsOn)
			((LightingScene*) scene)->light0->enable();
		break;
	case 1:
		((LightingScene*) scene)->light1->disable();
		if (((LightingScene*) scene)->light1IsOn)
			((LightingScene*) scene)->light1->enable();
		break;
	case 2:
		((LightingScene*) scene)->light2->disable();
		if (((LightingScene*) scene)->light2IsOn)
			((LightingScene*) scene)->light2->enable();
		break;
	case 3:
		((LightingScene*) scene)->light3->disable();
		if (((LightingScene*) scene)->light3IsOn)
			((LightingScene*) scene)->light3->enable();
		break;
	};
}

