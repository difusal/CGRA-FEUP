#include "CircleTool.h"

#include <algorithm>

void CircleTool::mousePressed(int x, int y) {
	// Reset start coordinates and active (current) coordinates
	sx = x;
	sy = y;
	currx = x;
	curry = y;

	// Activate XOR mode with inverted color to enable rubber-banding
	canvas->setXORMode();
	canvas->setColor(255);

	// Draw (one pixel)
	drawCircle(sx, sy, currx, curry);
}

void CircleTool::mouseDragged(int x, int y) {
	// Redraw previous rectangle (in XOR mode, will invert the color of all pixels, effectively erasing it)
	drawCircle(sx, sy, currx, curry);

	// Update current coordinates
	currx = x;
	curry = y;

	// Draw new line
	drawCircle(sx, sy, currx, curry);
}

void CircleTool::mouseReleased(int x, int y) {
	// Redraw previous rectangle to erase it
	drawCircle(sx, sy, currx, curry);

	// Set normal mode and color to draw final line
	canvas->setNormalMode();
	canvas->setColor(0);

	// draw final line
	drawCircle(sx, sy, x, y);
}

void CircleTool::drawCircle(int xi, int yi, int xf, int yf) {
	// y correction
	if (yi > yf)
		std::swap(yi, yf);

	// x correction
	if (xi > xf)
		std::swap(xi, xf);

	// drawing pixel by pixel
	for (int i = yi; i <= yf; i++)
		for (int j = xi; j <= xf; j++)
			canvas->setPixel(j, i);
}
