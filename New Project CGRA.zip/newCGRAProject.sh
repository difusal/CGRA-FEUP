echo "Creating new CGRA Project: $1"
cp -r CGRA\ Application CGRA\ Application1
mv CGRA\ Application1 $1
echo "Done!"